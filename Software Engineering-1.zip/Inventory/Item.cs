﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Inventory
{
    public partial class Item : Form
    {
        public Item()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\admin\Documents\Inventorydb.mdf;Integrated Security=True;Connect Timeout=30");
        void pp()
        {
            try
            {
                Con.Open();
                string Myquery = "Select *from itemTb";
                SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                itGV.DataSource = ds.Tables[0];
                Con.Close();
            }
            catch
            {

            }
        }
        void fillcategory()
        {
            string query = "select * from categoryTb";
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataReader rdr;
            try
            {
                Con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("categoryname",typeof(string));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                itcTb.ValueMember = "categoryname";
                itcTb.DataSource = dt;

                Con.Close();
            }
            catch
            {

            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void itidTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand("insert into itemTb values('" + itidTb.Text + "','" + itnameTb.Text + "','" + itqtTb.Text + "','" + itpTb.Text + "','" + itcTb.Text + "')", Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Item Enlisted Successfully!");
                Con.Close();
                pp();
            }
            catch
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand("update  itemTb set Itemname= '" + itnameTb.Text + "',Itemquantity= '" + itqtTb.Text + "',Itemprice= '" + itpTb.Text + "' where  ItemId = '" + itidTb.Text + "'", Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Item Updated Successfully!");
                Con.Close();
                pp();
            }
            catch
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (itidTb.Text == "")
            {
                MessageBox.Show("Enter the Item ID");
            }
            else
            {
                Con.Open();
                string myquery = "delete from itemTb where ItemId ='" + itidTb.Text + "';";
                SqlCommand cmd = new SqlCommand(myquery, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Item Deleted Successfully");
                Con.Close();
                pp();
            }
        }

        private void Item_Load(object sender, EventArgs e)
        {
            fillcategory();
        }

        private void itGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            itidTb.Text = itGV.SelectedRows[0].Cells[0].Value.ToString();

            itnameTb.Text = itGV.SelectedRows[0].Cells[1].Value.ToString();
            itqtTb.Text = itGV.SelectedRows[0].Cells[2].Value.ToString();
            itpTb.Text = itGV.SelectedRows[0].Cells[3].Value.ToString();
            itcTb.SelectedValue= itGV.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            orders f1 = new orders();
            f1.Show();

        }
    }
}
