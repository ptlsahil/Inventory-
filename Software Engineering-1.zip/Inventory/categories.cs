﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Inventory
{
    public partial class categories : Form
    {
        public categories()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\admin\Documents\Inventorydb.mdf;Integrated Security=True;Connect Timeout=30");
        void pp()
        {
            try
            {
                Con.Open();
                string Myquery = "Select *from categoryTb";
                SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                ctGV.DataSource = ds.Tables[0];
                Con.Close();
            }
            catch
            {

            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void csGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ctidTb.Text = ctGV.SelectedRows[0].Cells[0].Value.ToString();

            ctnameTb.Text = ctGV.SelectedRows[0].Cells[1].Value.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand("insert into categoryTb values('" + ctidTb.Text + "','" + ctnameTb.Text + "')", Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Category Enlisted Successfully!");
                Con.Close();
                pp();
            }
            catch
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand("update  categoryTb set categoryname= '" + ctnameTb.Text + "' where  categoryId = '" + ctidTb.Text + "'", Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Category Updated Successfully!");
                Con.Close();
                pp();
            }
            catch
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (ctidTb.Text == "")
            {
                MessageBox.Show("Enter the Category ID");
            }
            else
            {
                Con.Open();
                string myquery = "delete from categoryTb where categorId ='" + ctidTb.Text + "';";
                SqlCommand cmd = new SqlCommand(myquery, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Category Deleted Successfully");
                Con.Close();
                pp();
            }
        }

        private void categories_Load(object sender, EventArgs e)
        {
            pp();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Item f1 = new Item();
            f1.Show();

        }
    }
}
