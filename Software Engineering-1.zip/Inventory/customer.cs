﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Inventory
{
    public partial class customer : Form
    {
        public customer()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\admin\Documents\Inventorydb.mdf;Integrated Security=True;Connect Timeout=30");
        void pp()
        {
            try
            {
                Con.Open();
                string Myquery = "Select *from CustomerTb";
                SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                csGV.DataSource = ds.Tables[0];
                Con.Close();
            }
            catch
            {

            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand("insert into CustomerTb values('" + csidTb.Text + "','" + csnameTb.Text + "','" + cscnTb.Text + "' )", Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer Enlisted Successfully!");
                Con.Close();
                pp();
            }
            catch
            {

            }
        }

        private void customer_Load(object sender, EventArgs e)
        {
            pp();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (csidTb.Text == "")
            {
                MessageBox.Show("Enter the Customer ID");
            }
            else
            {
                Con.Open();
                string myquery = "delete from CustomerTb where CustomerId ='" + csidTb.Text + "';";
                SqlCommand cmd = new SqlCommand(myquery, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer Deleted Successfully");
                Con.Close();
                pp();
            }
        }

        private void csGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            csidTb.Text = csGV.SelectedRows[0].Cells[0].Value.ToString();

            csnameTb.Text = csGV.SelectedRows[0].Cells[1].Value.ToString();
           
            cscnTb.Text = csGV.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand("update  CustomerTb set Customername= '" + csnameTb.Text + "', Customercontact='" + cscnTb.Text + "' where  CustomerId = '" + csidTb.Text + "'", Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer Updated Successfully!");
                Con.Close();
                pp();
            }
            catch
            {

            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            categories f1 = new categories();
            f1.Show();

        }
    }
}
