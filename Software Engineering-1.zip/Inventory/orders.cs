﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Inventory
{
    public partial class orders : Form
    {
        public orders()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\admin\Documents\Inventorydb.mdf;Integrated Security=True;Connect Timeout=30");
        void pp()
        {
            try
            {
                Con.Open();
                string Myquery = "Select *from CustomerTb";
                SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                csGV.DataSource = ds.Tables[0];
                Con.Close();
            }
            catch
            {

            }
        }
        void ppitem()
        {
            try
            {
                Con.Open();
                string Myquery = "Select *from itemTb";
                SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                itGV.DataSource = ds.Tables[0];
                Con.Close();
            }
            catch
            {

            }
        }
        void pporder()
        {
            try
            {
                Con.Open();
                string Myquery = "Select *from orderTb";
                SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                itGV.DataSource = ds.Tables[0];
                Con.Close();
            }
            catch
            {

            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void csGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            csidTb.Text = csGV.SelectedRows[0].Cells[0].Value.ToString();
        }

        private void orders_Load(object sender, EventArgs e)
        {
            pp();
            ppitem();
            pporder();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void itGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           oidTb.Text = itGV.SelectedRows[0].Cells[0].Value.ToString();
           
        }

        private void csidTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
    }
}
